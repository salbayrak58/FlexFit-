import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class AndroidSmall9 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(6.7, 11.2, 6.7, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(19.8, 0, 0, 57),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 19.7),
                    width: 28.4,
                    height: 11.1,
                    child: SizedBox(
                      width: 28.4,
                      height: 11.1,
                      child: SvgPicture.asset(
                        'assets/vectors/image_x2.svg',
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 2.8, 0, 0),
                    child: Text(
                      'FlexFit',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w600,
                        fontSize: 20,
                        height: 1.4,
                        letterSpacing: -0.4,
                        color: Color(0xFF6D156A),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0.2, 0, 19.3),
                    child: SizedBox(
                      width: 66.7,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0.3, 5, 0.3),
                            child: SizedBox(
                              width: 17,
                              height: 10.7,
                              child: SvgPicture.asset(
                                'assets/vectors/mobile_signal_2_x2.svg',
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 5, 0.4),
                            child: SizedBox(
                              width: 15.3,
                              height: 11,
                              child: SvgPicture.asset(
                                'assets/vectors/wifi_9_x2.svg',
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child: SizedBox(
                              width: 24.3,
                              height: 11.3,
                              child: SvgPicture.asset(
                                'assets/vectors/battery_4_x2.svg',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 92.3, 85),
              child: Opacity(
                opacity: 0.8,
                child: Text(
                  'Hedefin ne?',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w600,
                    fontSize: 32,
                    color: Color(0xFF384E56),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(11.4, 0, 0, 10),
              child: Opacity(
                opacity: 0.2,
                child: Text(
                  'Kilo almak',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Color(0xFF6D156A),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(14, 0, 0, 16),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFF000000),
                ),
                child: Container(
                  width: 164,
                  height: 1,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10.7, 0, 0, 12),
              child: Opacity(
                opacity: 0.8,
                child: Text(
                  'Kilo vermek',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w600,
                    fontSize: 24,
                    color: Color(0xFF6D156A),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(14, 0, 0, 17),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFF000000),
                ),
                child: Container(
                  width: 164,
                  height: 1,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(13.7, 0, 0, 220),
              child: Opacity(
                opacity: 0.2,
                child: Text(
                  'Kas kazanmak',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Color(0xFF6D156A),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(11.3, 0, 11.3, 18),
              child: Align(
                alignment: Alignment.topRight,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    gradient: LinearGradient(
                      begin: Alignment(0, -1),
                      end: Alignment(0, 1),
                      colors: <Color>[Color(0xFF6D156A), Color(0xFFD328CC)],
                      stops: <double>[0, 1],
                    ),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(19.3, 5, 19.3, 6),
                    child: Opacity(
                      opacity: 0.5,
                      child: Text(
                        'ileri',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w600,
                          fontSize: 10,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(4.3, 0, 0, 13),
              child: Text(
                'en doğru sonuçlar için doktorunuza başvurun.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w500,
                  fontSize: 10,
                  height: 1.4,
                  letterSpacing: -0.2,
                  color: Color(0xFFDADADA),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(8, 0, 0, 0),
              width: 134,
              height: 5,
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFF000000),
                  borderRadius: BorderRadius.circular(100),
                ),
                child: Container(
                  width: 134,
                  height: 5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}