import 'package:flutter/material.dart';

import 'package:flutter_app/pages/android_small_1.dart';
import 'package:flutter_app/pages/android_small_10.dart';
import 'package:flutter_app/pages/android_small_2.dart';
import 'package:flutter_app/pages/android_small_3.dart';
import 'package:flutter_app/pages/android_small_4.dart';
import 'package:flutter_app/pages/android_small_5.dart';
import 'package:flutter_app/pages/android_small_6.dart';
import 'package:flutter_app/pages/android_small_7.dart';
import 'package:flutter_app/pages/android_small_8.dart';
import 'package:flutter_app/pages/android_small_9.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(

        body: AndroidSmall1(),
        // body: AndroidSmall10(),
        // body: AndroidSmall2(),
        // body: AndroidSmall3(),
        // body: AndroidSmall4(),
        // body: AndroidSmall5(),
        // body: AndroidSmall6(),
        // body: AndroidSmall7(),
        // body: AndroidSmall8(),
        // body: AndroidSmall9(),

      ),
    );
  }
}
